# Source/Test layout

Copy the supplied application's real source into this directory.

main/  -> application source
test/  -> QA automation
