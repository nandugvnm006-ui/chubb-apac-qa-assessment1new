@echo off
REM Placeholder only. Replace with the Maven Wrapper supplied by the application.
